from enum import Enum

class Genre(Enum):
    ROMAN = 1
    SCIENCE_FICTION = 2
    FANTASTIQUE = 3
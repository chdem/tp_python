class DocumentDejaEmpprunteException(Exception):
    pass
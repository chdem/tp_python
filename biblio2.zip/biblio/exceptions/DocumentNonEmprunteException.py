class DocumentNonEmprunteException(Exception):
    pass